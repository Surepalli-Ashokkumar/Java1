export class MedicineClass{
    id:number;
    name:string;
    description:string;
    category:string;
    price:number;
    photo:string;
     
}
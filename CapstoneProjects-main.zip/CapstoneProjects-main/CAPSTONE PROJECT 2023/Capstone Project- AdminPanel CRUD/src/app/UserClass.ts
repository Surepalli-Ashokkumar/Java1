export class UserClass
{
    id:number;
    name:string;
    email:string;
    country:string;
    login:number;
    password:string;
}
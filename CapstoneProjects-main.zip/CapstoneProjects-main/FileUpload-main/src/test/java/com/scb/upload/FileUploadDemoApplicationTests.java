package com.scb.upload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileUploadDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}


DOWNLOAD : JDK -11

link:https://www.oracle.com/in/java/technologies/javase/jdk11-archive-downloads.html


DOWNLOAD : ECLIPSE ENTERPRISE VERSION

Link: https://www.eclipse.org/downloads/packages/release/kepler/sr2/eclipse-ide-java-ee-developers


GIT INSTALLATION:
Link: https://git-scm.com/downloads